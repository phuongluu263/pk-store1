<ul class = "admincp_list">
	<li><a href="index.php?action=quanlydanhmucsanpham&query=them">Quản lý danh mục sản phẩm</a></li>

	<li><a href="index.php?action=quanlysanpham&query=them">Quản lý sản phẩm</a></li>

	<li><a href="index.php?action=quanlydanhmucbaiviet&query=them">Quản lý danh mục bài viết</a></li>

	<li><a href="index.php?action=quanlybaiviet&query=them">Quản lý bài viết</a></li>

	<li><a href="index.php?action=quanlyweb&query=capnhat">Quản lý thông tin website</a></li>
	
	<li><a href="index.php?action=quanlydonhang&query=lietke">Quản lý đơn hàng</a></li>
</ul>