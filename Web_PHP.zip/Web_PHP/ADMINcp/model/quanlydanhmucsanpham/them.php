<p>Thêm Danh Mục Sản Phẩm</p>
<table border="1" width="30%" style="border-collapse: collapse;">
	<form method="POST" action="model/quanlydanhmucsanpham/xuly.php">	
	  <tr>
	    <td>Tên Danh Mục</td>
	    <td><input type="text" size="30%" name="tendanhmuc"></td>
	  </tr>
	  <tr>
	    <td>Số thứ tự</td>
	    <td><input type="text" size="30%" name="thutu"></td>
	  </tr>
	  <tr>
	  	<td colspan="2"><input type="submit" name="themdanhmuc" value="Thêm danh mục sản phẩm" ></td>
	  </tr>
	</form>  
</table>
