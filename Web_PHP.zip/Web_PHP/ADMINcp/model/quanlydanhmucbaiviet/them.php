<p>Thêm Danh Mục Bài Viết</p>
<table border="1" width="50%" style="border-collapse: collapse;">
	<form method="POST" action="model/quanlydanhmucbaiviet/xuly.php">	
	  <tr>
	    <td>Tên Danh Mục Bài Viết</td>
	    <td><input type="text"  size="50%" name="tendanhmucbaiviet"></td>
	  </tr>
	  <tr>
	    <td>Số thứ tự</td>
	    <td><input type="text" size="50%" name="thutu"></td>
	  </tr>
	  <tr>
	  	<td colspan="2"><input type="submit" name="themdanhmucbaiviet" value="Thêm danh mục bài viết" ></td>
	  </tr>
	</form>  
</table>
