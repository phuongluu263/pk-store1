<!DOCTYPE html>
<html>
<body>

<?php
//echo "My first PHP script!";
?>

<?php
$txt = "PHP";
//echo "I love $txt!";
?>

<?php
$txt = "Hello world!";
$x = 5;
$y = 10.5;
$sum=$x+$y;
echo"$sum";
?>

</body>
</html>