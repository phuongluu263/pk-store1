<div class="Clear"></div>
		<div class = "Footer">
			<p class="Footer_Copyright">Copy_Right By PhuongKiet 2021</p>
		</div>